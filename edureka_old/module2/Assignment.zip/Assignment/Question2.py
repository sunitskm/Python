#Run on python 2.7
name = raw_input("Enter your name: ")
print ("Hello " + name)
