#Run on python 2.7
temp_far = float(raw_input("Enter the temperature in Farenheit "))

temp_cel = 5/9.0*(temp_far-32)
print("Temperature in Fareheit is %.1f" %(temp_cel))
