a = [4,7,3,2,5,9]
print
for i in a:
    print("Element is %d and Position %d" %(i,a.index(i)))
