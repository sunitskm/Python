hours = int(raw_input("Enter hours: "))
rate = float(raw_input("Enter rate: "))
pay = hours * rate
print("%.2f" %(pay))
