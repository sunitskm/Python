s = "Discover, Learning, with, Edureka"
#num_a = s.count('a')
def count_characters(string,c):
    print("Number of lower case %s = %d" %(c,string.count(c)))
#print("Number of lower case a = %d" %(s.count('a')))
#print("Number of lower case o = %d" %(s.count('o')))
#print("Number of lower case a = %d" %(s.count('a')))
count_characters(s,'a')
count_characters(s,'o')
count_characters(s,'L')
count_characters(s,'N')
