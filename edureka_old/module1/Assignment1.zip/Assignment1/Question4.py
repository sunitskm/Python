c = 'C'
num = 78
num_fl = 3.143212
print("Value in character is %c" %(c))
print("Value in signed decimal integer is %d" %(num))
print("Value in Octal is %o" %(num))
print("Value in hexadecinal is %X" %(num))
print("Value in floating point number is %f" %(num_fl))
print("Value in floating point exponent is %e" %(num_fl))
